import json
import boto3
import uuid
import os
from datetime import datetime

sqs = boto3.client('sqs')
dynamodb = boto3.client('dynamodb')

def handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        request_id = str(uuid.uuid4())
        
        # Store metadata in DynamoDB
        dynamodb.put_item(
            TableName=os.environ['TABLE_NAME'],
            Item={
                'requestId': {'S': request_id},
                'status': {'S': 'pending'},
                'data': {'S': json.dumps(body)},
                'timestamp': {'S': datetime.now().isoformat()}
            }
        )
        
        # Send to SQS for async processing
        sqs.send_message(
            QueueUrl=os.environ['QUEUE_URL'],
            MessageBody=json.dumps({
                'requestId': request_id,
                'data': body
            })
        )
        
        return {
            'statusCode': 202,
            'body': json.dumps({'requestId': request_id, 'status': 'accepted'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
