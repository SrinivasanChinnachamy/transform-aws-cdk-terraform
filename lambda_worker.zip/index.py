import json
import boto3
import os
import time

s3 = boto3.client('s3')
dynamodb = boto3.client('dynamodb')
sns = boto3.client('sns')

def handler(event, context):
    for record in event['Records']:
        try:
            message = json.loads(record['body'])
            request_id = message['requestId']
            data = message['data']
            
            # Simulate processing
            time.sleep(2)
            result = f"Processed: {json.dumps(data)}"
            
            # Store result in S3
            s3.put_object(
                Bucket=os.environ['BUCKET_NAME'],
                Key=f"results/{request_id}.json",
                Body=json.dumps({'result': result, 'requestId': request_id})
            )
            
            # Update status in DynamoDB
            dynamodb.update_item(
                TableName=os.environ['TABLE_NAME'],
                Key={'requestId': {'S': request_id}},
                UpdateExpression='SET #status = :status, #result = :result',
                ExpressionAttributeNames={'#status': 'status', '#result': 'result'},
                ExpressionAttributeValues={
                    ':status': {'S': 'completed'},
                    ':result': {'S': f"s3://{os.environ['BUCKET_NAME']}/results/{request_id}.json"}
                }
            )
            
        except Exception as e:
            error_msg = f"Error processing request {message.get('requestId', 'unknown')}: {str(e)}"
            print(error_msg)
            
            # Notify SRE team about failure
            sns.publish(
                TopicArn=os.environ['TOPIC_ARN'],
                Subject='Lambda Processing Failure - Action Required',
                Message=f"Request ID: {message.get('requestId', 'unknown')}\\nError: {str(e)}\\nMessage: {json.dumps(message)}"
            )
            raise
    
    return {'statusCode': 200}
